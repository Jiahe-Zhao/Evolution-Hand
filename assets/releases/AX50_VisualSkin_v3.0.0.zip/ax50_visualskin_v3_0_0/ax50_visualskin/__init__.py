"""AX50 VisualSkin v3 bilateral Newton asset and coupled runtime."""
from pathlib import Path
import hashlib
import sys
__version__ = '3.0.0'
ROOT = Path(__file__).resolve().parent

def activate_newton():
    """Use the frozen, locally patched Newton implementation without changing site-packages."""
    bundled = ROOT / '_vendor'
    if 'newton' in sys.modules:
        path = Path(sys.modules['newton'].__file__).parent / '_src/solvers/vbd/particle_vbd_kernels.py'
        expected = bundled / 'newton/_src/solvers/vbd/particle_vbd_kernels.py'
        if hashlib.sha256(path.read_bytes()).digest() != hashlib.sha256(expected.read_bytes()).digest():
            raise RuntimeError('Import ax50_visualskin before newton: this asset uses the bundled bending-damping correction.')
    else:
        sys.path.insert(0, str(bundled))

activate_newton()

def asset_path(side='left'):
    if side not in ('left', 'right'):
        raise ValueError('side must be left or right')
    return ROOT / 'assets' / side

def __getattr__(name):
    if name == 'HandRuntime':
        from .runtime import HandRuntime
        return HandRuntime
    if name == 'VisualSkin':
        from .visual import VisualSkin
        return VisualSkin
    raise AttributeError(name)
