"""Observe every physics substep; no clipping, smoothing, or physics feedback changes."""
import warp as wp

@wp.kernel
def collect_soft_load(count:wp.array(dtype=int),indices:wp.array(dtype=wp.vec3i),bary:wp.array(dtype=wp.vec3),shape:wp.array(dtype=int),shape_body:wp.array(dtype=int),forces:wp.array(dtype=wp.vec3),regions:wp.array(dtype=int),hand_count:int,current:wp.array(dtype=float)):
    i=wp.tid()
    if i<count[0]:
        b=shape_body[shape[i]]
        if b<0 or b>=hand_count:
            for j in range(3):
                p=indices[i][j];weight=bary[i][j]
                if p>=0 and p<regions.shape[0] and weight>0.:
                    region=regions[p]
                    if region>=0:wp.atomic_add(current,region,weight*wp.length(forces[i]))

@wp.kernel
def record_peak(current:wp.array(dtype=float),peak:wp.array(dtype=float)):
    i=wp.tid();peak[i]=wp.max(peak[i],current[i])

@wp.kernel
def collect_rigid_load(count:wp.array(dtype=int),shape0:wp.array(dtype=int),shape1:wp.array(dtype=int),shape_body:wp.array(dtype=int),forces:wp.array(dtype=wp.spatial_vector),hand_count:int,current:wp.array(dtype=float)):
    i=wp.tid()
    if i<count[0]:
        a=shape_body[shape0[i]];b=shape_body[shape1[i]];magnitude=wp.length(wp.spatial_top(forces[i]))
        if a>=0 and a<hand_count and (b<0 or b>=hand_count):wp.atomic_add(current,a,magnitude)
        if b>=0 and b<hand_count and (a<0 or a>=hand_count):wp.atomic_add(current,b,magnitude)
