"""Continuous display surface driven by live body poses. Not collision geometry."""
import numpy as np
import warp as wp
from scipy.spatial.transform import Rotation
from . import asset_path

@wp.kernel
def deform(rest:wp.array(dtype=wp.vec3), ids:wp.array(dtype=wp.vec4i), weights:wp.array(dtype=wp.vec4), delta:wp.array(dtype=wp.transform), output:wp.array(dtype=wp.vec3)):
    i=wp.tid();q=wp.quat(0.,0.,0.,0.);dual=wp.quat(0.,0.,0.,0.);ref=wp.transform_get_rotation(delta[ids[i][0]])
    for j in range(4):
        D=delta[ids[i][j]];qr=wp.transform_get_rotation(D);t=wp.transform_get_translation(D)
        sign=float(1.)
        if wp.dot(qr,ref)<0.:sign=-1.
        w=weights[i][j]*sign;q=q+qr*w;dual=dual+(wp.quat(t[0],t[1],t[2],0.)*qr)*(0.5*w)
    norm=wp.sqrt(wp.dot(q,q));q=q/norm;dual=dual/norm
    translation=(dual*wp.quat_inverse(q))*2.
    output[i]=wp.quat_rotate(q,rest[i])+wp.vec3(translation[0],translation[1],translation[2])

class VisualSkin:
    def __init__(self, side, body_names, device='cuda:0'):
        self.side=side;self.device=device;z=dict(np.load(asset_path(side)/'display_skin.npz'))
        self.faces=z['faces'];self.names=[str(x).rsplit('/',1)[-1] for x in body_names]
        rest_names=list(z['bone_names']);used=np.unique(z['bone_indices']);self.used=used
        self.current_ids=np.array([self.names.index(str(rest_names[i])) for i in used]);self.rest_q=z['rest_body_q'][used]
        mapping={int(i):j for j,i in enumerate(used)};ids=np.array([[mapping[int(i)] for i in row] for row in z['bone_indices']],np.int32)
        with wp.ScopedDevice(device):
            self.rest=wp.array(z['vertices'],dtype=wp.vec3);self.ids=wp.array(ids,dtype=wp.vec4i);self.weights=wp.array(z['weights'],dtype=wp.vec4);self.delta=wp.empty(len(used),dtype=wp.transform);self.vertices=wp.empty(len(z['vertices']),dtype=wp.vec3)
        self._rest_rot=Rotation.from_quat(self.rest_q[:,3:]);self._rest_inv=self._rest_rot.inv()
    def update(self, body_q):
        """Return (vertices, faces) in world metres from a Newton state.body_q or NumPy array."""
        poses=body_q.numpy() if isinstance(body_q,wp.array) else np.asarray(body_q)
        poses=poses[self.current_ids];rot=Rotation.from_quat(poses[:,3:])*self._rest_inv
        trans=poses[:,:3]-rot.apply(self.rest_q[:,:3]);self.delta.assign(np.column_stack([trans,rot.as_quat()]).astype(np.float32))
        wp.launch(deform,len(self.vertices),inputs=[self.rest,self.ids,self.weights,self.delta,self.vertices],device=self.device)
        return self.vertices.numpy(),self.faces
    def write_usd_points(self, mesh, body_q, world_to_mesh=None):
        """Update a USD Mesh in its actual local frame, including mirrored right-hand parent transforms."""
        from pxr import Vt,UsdGeom
        vertices,_=self.update(body_q)
        if world_to_mesh is None:
            world_to_mesh=np.asarray(UsdGeom.XformCache().GetLocalToWorldTransform(mesh.GetPrim()).GetInverse()).T
        vertices=vertices@np.asarray(world_to_mesh)[:3,:3].T+np.asarray(world_to_mesh)[:3,3]
        mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(vertices.astype(np.float32)))
