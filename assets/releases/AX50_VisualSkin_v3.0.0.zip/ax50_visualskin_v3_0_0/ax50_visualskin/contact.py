import warp as wp
from newton._src.solvers.vbd.rigid_vbd_kernels import _eval_soft_ef_contact
@wp.kernel
def contact_readback(
    contact_count: wp.array(dtype=int),
    indices: wp.array(dtype=wp.vec3i),
    bary: wp.array(dtype=wp.vec3),
    contact_shape: wp.array(dtype=int),
    contact_body_pos: wp.array(dtype=wp.vec3),
    contact_body_vel: wp.array(dtype=wp.vec3),
    contact_normal: wp.array(dtype=wp.vec3),
    p_q: wp.array(dtype=wp.vec3),
    p_q_prev: wp.array(dtype=wp.vec3),
    p_radius: wp.array(dtype=float),
    ke: wp.array(dtype=float),
    kd: wp.array(dtype=float),
    mu: wp.array(dtype=float),
    friction_epsilon: float,
    shape_body: wp.array(dtype=int),
    body_q: wp.array(dtype=wp.transform),
    body_q_prev: wp.array(dtype=wp.transform),
    body_qd: wp.array(dtype=wp.spatial_vector),
    body_com: wp.array(dtype=wp.vec3),
    shape_margin: wp.array(dtype=float),
    dt: float,
    probe_body: int,
    out_f: wp.array(dtype=wp.vec3),
    out_depth: wp.array(dtype=float),
    out_normal: wp.array(dtype=wp.vec3),
    out_bx: wp.array(dtype=wp.vec3),
    out_reaction: wp.array(dtype=wp.vec3),
):
    i = wp.tid()
    if i >= contact_count[0]:
        return

    corners = indices[i]
    b = bary[i]
    f, _h, bx = _eval_soft_ef_contact(
        i,
        corners,
        b,
        p_q,
        p_q_prev,
        p_radius,
        ke[i],
        kd[i],
        mu[i],
        friction_epsilon,
        shape_body,
        body_q,
        body_q_prev,
        body_qd,
        body_com,
        contact_shape,
        contact_body_pos,
        contact_body_vel,
        contact_normal,
        shape_margin,
        dt,
    )
    out_f[i] = f

    # geometric penetration of the same barycentric point
    x = b[0] * p_q[corners[0]]
    radius = p_radius[corners[0]]
    if corners[1] >= 0:
        x += b[1] * p_q[corners[1]]
        radius = wp.max(radius, p_radius[corners[1]])
    if corners[2] >= 0:
        x += b[2] * p_q[corners[2]]
        radius = wp.max(radius, p_radius[corners[2]])

    si = contact_shape[i]
    bi = shape_body[si]
    X = wp.transform_identity()
    if bi >= 0:
        X = body_q[bi]
    bxx = wp.transform_point(X, contact_body_pos[i])
    margin = shape_margin[si] if shape_margin.shape[0] > 0 else 0.0
    out_depth[i] = -(wp.dot(contact_normal[i], x - bxx) - radius - margin)
    out_normal[i] = contact_normal[i]
    out_bx[i] = bxx
    if shape_body[contact_shape[i]] == probe_body:
        wp.atomic_add(out_reaction, 0, -f)

