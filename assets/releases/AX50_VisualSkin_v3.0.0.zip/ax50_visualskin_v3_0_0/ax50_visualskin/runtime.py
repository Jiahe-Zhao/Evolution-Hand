"""Independent pad sample, MJWarp joints and VBD tissue with bidirectional loads."""
from pathlib import Path
import sys,json,time
import numpy as np,warp as wp,newton
from pxr import Usd,UsdGeom,UsdPhysics as P, Vt, Gf
from newton.solvers import SolverMuJoCo,SolverVBD

ROOT=Path(__file__).resolve().parent
from .contact import contact_readback
from .sensors import collect_soft_load,record_peak,collect_rigid_load
from . import asset_path
@wp.kernel
def anchors(q:wp.array(dtype=wp.vec3),qd:wp.array(dtype=wp.vec3),bq:wp.array(dtype=wp.transform),bv:wp.array(dtype=wp.spatial_vector),com:wp.array(dtype=wp.vec3),pi:wp.array(dtype=int),gi:wp.array(dtype=int),bi:wp.array(dtype=int),local:wp.array(dtype=wp.vec3),k:wp.array(dtype=float),bf:wp.array(dtype=wp.spatial_vector),out:wp.array(dtype=wp.vec3)):
 i=wp.tid();b=bi[i];x=wp.transform_point(bq[b],local[i]);center=wp.transform_point(bq[b],com[b]);r=x-center
 vel=wp.spatial_top(bv[b])+wp.cross(wp.spatial_bottom(bv[b]),r)
 f=k[i]*(q[pi[i]]-x)
 wp.atomic_add(bf,b,wp.spatial_vector(f,wp.cross(r,f)));out[i]=-f;q[gi[i]]=x;qd[gi[i]]=vel
@wp.kernel
def filter_bridge_contacts(count:wp.array(dtype=int),ii:wp.array(dtype=wp.vec3i),pp:wp.array(dtype=int),bb:wp.array(dtype=wp.vec3),ss:wp.array(dtype=int),xp:wp.array(dtype=wp.vec3),xv:wp.array(dtype=wp.vec3),nn:wp.array(dtype=wp.vec3),lo:int,hi:int,oc:wp.array(dtype=int),oi:wp.array(dtype=wp.vec3i),op:wp.array(dtype=int),ob:wp.array(dtype=wp.vec3),os:wp.array(dtype=int),oxp:wp.array(dtype=wp.vec3),oxv:wp.array(dtype=wp.vec3),on:wp.array(dtype=wp.vec3)):
 i=wp.tid()
 if i<count[0]:
  v=ii[i];excluded=False
  for k in range(3):
   if v[k]>=lo and v[k]<hi:excluded=True
  if not excluded:
   j=wp.atomic_add(oc,0,1);oi[j]=v;op[j]=pp[i];ob[j]=bb[i];os[j]=ss[i];oxp[j]=xp[i];oxv[j]=xv[i];on[j]=nn[i]
@wp.kernel
def sync_ghosts(q:wp.array(dtype=wp.vec3),qd:wp.array(dtype=wp.vec3),bq:wp.array(dtype=wp.transform),bv:wp.array(dtype=wp.spatial_vector),com:wp.array(dtype=wp.vec3),gi:wp.array(dtype=int),bi:wp.array(dtype=int),local:wp.array(dtype=wp.vec3)):
 i=wp.tid();b=bi[i];x=wp.transform_point(bq[b],local[i]);center=wp.transform_point(bq[b],com[b]);q[gi[i]]=x;qd[gi[i]]=wp.spatial_top(bv[b])+wp.cross(wp.spatial_bottom(bv[b]),x-center)
@wp.kernel
def control_pd(q:wp.array(dtype=float),qd:wp.array(dtype=float),target:wp.array(dtype=float),caps:wp.array(dtype=float),force:wp.array(dtype=float)):
 i=wp.tid();force[i]=wp.clamp(4.0*(target[i]-q[i])-.08*qd[i],-caps[i],caps[i])
@wp.kernel
def add_feedback(dst:wp.array(dtype=wp.spatial_vector),src:wp.array(dtype=wp.spatial_vector)):
 i=wp.tid();dst[i]+=src[i]
@wp.kernel
def contact_reaction(count:wp.array(dtype=int),shapes:wp.array(dtype=int),sb:wp.array(dtype=int),forces:wp.array(dtype=wp.vec3),points:wp.array(dtype=wp.vec3),bq:wp.array(dtype=wp.transform),com:wp.array(dtype=wp.vec3),out:wp.array(dtype=wp.spatial_vector)):
 i=wp.tid()
 if i<count[0]:
  b=sb[shapes[i]]
  if b>=0:
   f=-forces[i];center=wp.transform_point(bq[b],com[b]);wp.atomic_add(out,b,wp.spatial_vector(f,wp.cross(points[i]-center,f)))
@wp.kernel
def move_probe(old:wp.array(dtype=wp.transform),new:wp.array(dtype=wp.transform),v0:wp.array(dtype=wp.spatial_vector),v1:wp.array(dtype=wp.spatial_vector),probe:int,vel:wp.array(dtype=wp.vec3),dt:float):
 x=wp.transform_get_translation(old[probe])+vel[0]*dt;new[probe]=wp.transform(x,wp.quat_identity());v0[probe]=wp.spatial_vector(vel[0],wp.vec3(0.));v1[probe]=v0[probe]
class HandRuntime:
 def __init__(self, side='left', wrist='locked', iterations=25, fixed_skeleton=False, position=(0,0,0), orientation=(0,0,0,1), gravity=(0,0,0), scene_builder=None, device='cuda:0', cache_dir=None, probe=False, probe_contact_ke=20000.0):
  import os
  if wrist not in ('locked','six_axis'):raise ValueError('wrist must be locked or six_axis')
  self.side=side;self.wrist=wrist;self.device=device;self.variant='pads';self.asset=asset_path(side)
  self.probe_contact_ke=probe_contact_ke;self.enable_probe=probe;self.position=tuple(position);self.orientation=tuple(orientation);self.time=0.;self.iterations=iterations
  self.cache_dir=Path(cache_dir) if cache_dir else Path(os.environ.get('XDG_CACHE_HOME',Path.home()/'.cache'))/'ax50_visualskin_v3'/'sdf'
  self.cache_dir.mkdir(parents=True,exist_ok=True)
  with wp.ScopedDevice(device):self._build(iterations,fixed_skeleton,gravity,scene_builder)
 def _build(self,iterations,indent,gravity,scene_builder):
  variant='pads';self.bridges=dict(np.load(self.asset/'bridges.npz'));self.pads=dict(np.load(self.asset/'pads.npz'));self.palm=dict(np.load(self.asset/'membrane.npz'));spec=json.loads((self.asset/'slidingskin.json').read_text())
  self.convention=json.loads((self.asset/'joint_convention.json').read_text())['canonical_to_native']
  st=Usd.Stage.Open(str(self.asset/'hand.usda'));st.SetEditTarget(st.GetSessionLayer())
  if self.wrist=='locked':
   for p in list(st.Traverse()):
    if p.IsA(P.Joint) and p.GetName().startswith(('wrist_','diagnostic_wrist_')):P.FixedJoint.Define(st,p.GetPath())
  mount=wp.transform(self.position,self.orientation)
  b=newton.ModelBuilder(gravity=gravity);b.add_usd(st,xform=mount,collapse_fixed_joints=False,enable_self_collisions=True);b.rigid_gap=0.;b.shape_gap[:]=[0.]*len(b.shape_gap)
  self.body_names=[x.split('/')[-1] for x in b.body_label];self.hand_body_count=b.body_count
  self.joint_names=['']*len(b.joint_target_ke)
  for j,label in enumerate(b.joint_label):
   if b.joint_type[j]==newton.JointType.FIXED:continue
   i=b.joint_qd_start[j];self.joint_names[i]=label.split('/')[-1];b.joint_target_mode[i]=newton.JointTargetMode.NONE;b.joint_target_ke[i]=0.;b.joint_target_kd[i]=0.;b.joint_armature[i]=.00008
  if indent:
   b.body_flags[:]=[int(newton.BodyFlags.KINEMATIC)]*b.body_count;b.joint_enabled[:]=[False]*b.joint_count
  self.probe=-999
  if self.enable_probe:
   self.probe=b.add_body(xform=wp.transform((.4,.4,.4),wp.quat_identity()),mass=0.,is_kinematic=True,label='probe')
   b.add_shape_sphere(self.probe,radius=.002,cfg=newton.ModelBuilder.ShapeConfig(density=0.,ke=self.probe_contact_ke,kd=10.,mu=.2),label='probe_sphere')
  if scene_builder is not None:
   n=b.joint_count;scene_builder(b)
   if b.joint_count!=n:raise ValueError('scene_builder supports props; add articulated robots through a custom coupled scene adapter')
  # Keep the approved palm geometry and its 3% runtime bending damping.
  z=self.palm;self.palm_count=len(z['surface_rest_vertices_m'])
  b.add_cloth_mesh(pos=self.position,rot=wp.quat(*self.orientation),scale=1.,vel=(0,0,0),vertices=z['surface_rest_vertices_m'],indices=z['surface_faces'].flatten(),density=spec['surface_density_kg_m2'],tri_ke=spec['tri_ke'],tri_ka=spec['tri_ka'],tri_kd=spec['tri_kd'],edge_ke=spec['edge_ke'],edge_kd=spec['edge_kd']*.03,particle_radius=spec['particle_radius_m'])
  self.pad_offset=b.particle_count
  if variant=='pads':
   z=self.pads;b.add_soft_mesh(pos=self.position,rot=wp.quat(*self.orientation),scale=1.,vel=(0,0,0),vertices=z['vertices'],indices=z['tets'].flatten(),density=1000.,k_mu=5000.,k_lambda=10000.,k_damp=.02,particle_radius=.00005,add_surface_mesh_edges=True)
  self.bridge_offset=b.particle_count;self.bridge_tri_offset=b.tri_count;self.bridge_edge_offset=b.edge_count
  if variant=='pads':
   z=self.bridges;b.add_cloth_mesh(pos=self.position,rot=wp.quat(*self.orientation),scale=1.,vel=(0,0,0),vertices=z['vertices'],indices=z['faces'].flatten(),density=.35,tri_ke=2.,tri_ka=2.,tri_kd=.0001,edge_ke=2e-8,edge_kd=6e-10,particle_radius=.00005)
   # Bridge edges attach to their supporting bones; adjacent pads carry pressure independently.
  self.real_count=b.particle_count
  self.bridge_tri_end=b.tri_count;self.bridge_edge_end=b.edge_count
  interior=(np.setdiff1d(np.arange(len(self.pads["vertices"])),np.unique(self.pads["faces"]))+self.pad_offset).tolist() if variant=="pads" else []
  z=self.palm;pis=list(z['anchor_particle']);bis=[self.body_names.index(str(z['bone_names'][j])) for j in z['anchor_bone']];loc=list(z['anchor_local_m']);ks=list(z['anchor_stiffness_N_m'])
  if variant=='pads':
   z=self.pads;pis+=list(z['anchor_particle']+self.pad_offset);bis +=[self.body_names.index(str(z['bone_names'][j])) for j in z['anchor_bone']];loc+=list(z['anchor_local']);ks +=[100.]*len(z['anchor_particle'])
  if variant=='pads':
   z=self.bridges;pis+=list(z['root_pi']+self.bridge_offset);bis +=[self.body_names.index(str(self.pads['bone_names'][i])) for i in z['root_bone']];loc+=list(z['root_local']);ks +=[10.]*len(z['root_pi'])
  ghost=[]
  for pi,bi,ll,k in zip(pis,bis,loc,ks):
   x=wp.transform_point(b.body_q[bi],wp.vec3(*ll));a=b.add_particle(pos=x,vel=(0,0,0),mass=0.,radius=0.,flags=0);b.add_spring(int(pi),a,float(k),0.,0.);b.spring_rest_length[-1]=0.;ghost.append(a)
  seen=set()
  for mesh in b.shape_source:
   if isinstance(mesh,newton.Mesh) and id(mesh) not in seen:mesh.build_sdf(device=self.device,target_voxel_size=.00025,narrow_band_range=(-.002,.002),margin=.002,cache_dir=str(self.cache_dir));seen.add(id(mesh))
  b.color();b.request_contact_attributes('force');self.model=m=b.finalize(device=self.device);newton.eval_fk(m,m.joint_q,m.joint_qd,m);m.soft_contact_ke=2e4;m.soft_contact_kd=10.;m.soft_contact_mu=.15
  def pipeline(mm):return newton.CollisionPipeline(mm,broad_phase='sap',rigid_contact_max=8192,soft_contact_max=131072,soft_contact_margin=.0005,enable_rigid_soft_full_surface_contact=True)
  self.indent=indent;self.vm=m
  if not indent:self.rigid=SolverMuJoCo(m,use_mujoco_contacts=False,use_mujoco_cpu=False,nconmax=8192,njmax=65536,integrator='implicitfast')
  all_tri=list(range(m.tri_count));bridge_tri=list(range(self.bridge_tri_offset,self.bridge_tri_end));all_edge=list(range(m.edge_count));bridge_edges=list(range(self.bridge_edge_offset,self.bridge_edge_end))
  vf={i:bridge_tri for i in range(m.particle_count)} if variant=='pads' else {}
  for i in ghost+interior+list(range(self.bridge_offset,self.real_count)):vf[int(i)]=all_tri
  ef={i:bridge_edges for i in range(m.edge_count)} if variant=='pads' else {}
  for i in bridge_edges:ef[i]=all_edge
  self.vbd=SolverVBD(m,iterations=iterations,integrate_with_external_rigid_solver=True,particle_enable_self_contact=True,particle_self_contact_margin=.0002,particle_self_contact_gap=.0001,particle_rest_shape_contact_exclusion_radius=.0005,particle_external_vertex_contact_filtering_map=vf,particle_external_edge_contact_filtering_map=ef,rigid_body_contact_buffer_size=4096,rigid_body_particle_contact_buffer_size=32768)
  self.feedback=wp.zeros(m.body_count,dtype=wp.spatial_vector);self.probe_velocity=wp.zeros(1,dtype=wp.vec3)
  self.collision=pipeline(m);self.raw_contacts=self.collision.contacts();self.contacts=self.collision.contacts();self.rigid_observation=self.collision.contacts()
  for key in vars(self.raw_contacts):
   if key.startswith('rigid_contact_'):setattr(self.contacts,key,getattr(self.raw_contacts,key))
  self.contacts.contact_generation=self.raw_contacts.contact_generation
  self.state=m.state();self.next=m.state();newton.eval_fk(m,m.joint_q,m.joint_qd,self.state);wp.copy(self.next.body_q,self.state.body_q);self.control=m.control()
  self.pi=wp.array(np.array(pis,dtype=int),dtype=int);self.gi=wp.array(ghost,dtype=int);self.bi=wp.array(bis,dtype=int);self.local=wp.array(np.array(loc),dtype=wp.vec3);self.k=wp.array(np.array(ks,dtype=float),dtype=float);self.anchor_force=wp.zeros(len(pis),dtype=wp.vec3)
  self.target=wp.clone(self.state.joint_q);self.caps=wp.array(np.array([.8 if n.startswith('digit_') else 1. for n in self.joint_names]),dtype=float)
  self.out_f=wp.zeros(131072,dtype=wp.vec3);self.out_depth=wp.zeros(131072);self.out_normal=wp.zeros(131072,dtype=wp.vec3);self.out_bx=wp.zeros(131072,dtype=wp.vec3);self.out_reaction=wp.zeros(1,dtype=wp.vec3)
  self.action_names=[n for n in self.joint_names if n and n!='tissue']
  self.action_indices=np.array([self.joint_names.index(n) for n in self.action_names],dtype=int)
  self.signs=np.array([self.convention[n] for n in self.action_names])
  self._initial_q=self.state.joint_q.numpy().copy()
  lower=m.joint_limit_lower.numpy()[self.action_indices]*self.signs;upper=m.joint_limit_upper.numpy()[self.action_indices]*self.signs
  self.action_lower=np.minimum(lower,upper);self.action_upper=np.maximum(lower,upper)
  self.region_names=['palm','index_proximal','index_middle','index_distal']
  self.regions=np.full(self.real_count,-1,dtype=int);self.regions[:self.palm_count]=0
  z=self.pads;M=z['rest_body_matrices'][0];local=(z['vertices']-M[:3,3])@M[:3,:3]
  self.regions[self.pad_offset:self.bridge_offset]=np.searchsorted([.039,.063],local[:,2])+1
  self.body_names_all=[n.rsplit('/',1)[-1] for n in m.body_label]
  self.region_ids=wp.array(self.regions,dtype=int);self.current_soft_load=wp.zeros(4);self.peak_soft_load=wp.zeros(4);self.current_rigid_load=wp.zeros(self.hand_body_count);self.peak_rigid_load=wp.zeros(self.hand_body_count)

 def step(self,dt=.00025):
  self.state.clear_forces();wp.launch(anchors,len(self.pi),inputs=[self.state.particle_q,self.state.particle_qd,self.state.body_q,self.state.body_qd,self.model.body_com,self.pi,self.gi,self.bi,self.local,self.k,self.state.body_f,self.anchor_force])
  if not self.indent:
   wp.launch(add_feedback,self.model.body_count,inputs=[self.state.body_f,self.feedback]);wp.launch(control_pd,len(self.joint_names),inputs=[self.state.joint_q,self.state.joint_qd,self.target,self.caps,self.control.joint_f])
  if self.indent and self.enable_probe:wp.launch(move_probe,1,inputs=[self.state.body_q,self.next.body_q,self.state.body_qd,self.next.body_qd,self.probe,self.probe_velocity,dt])
  self.collision.collide(self.state,self.raw_contacts);self.contacts.soft_contact_count.zero_();c=self.raw_contacts;d=self.contacts
  wp.launch(filter_bridge_contacts,c.soft_contact_max,inputs=[c.soft_contact_count,c.soft_contact_indices,c.soft_contact_particle,c.soft_contact_barycentric,c.soft_contact_shape,c.soft_contact_body_pos,c.soft_contact_body_vel,c.soft_contact_normal,self.bridge_offset,self.real_count,d.soft_contact_count,d.soft_contact_indices,d.soft_contact_particle,d.soft_contact_barycentric,d.soft_contact_shape,d.soft_contact_body_pos,d.soft_contact_body_vel,d.soft_contact_normal])
  if not self.indent:
   self.rigid.step(self.state,self.next,self.control,self.contacts,dt)
   wp.launch(sync_ghosts,len(self.pi),inputs=[self.state.particle_q,self.state.particle_qd,self.next.body_q,self.next.body_qd,self.model.body_com,self.gi,self.bi,self.local])
  self.vbd.step(self.state,self.next,self.control,self.contacts,dt);self.state,self.next=self.next,self.state
  self.time+=dt
  self.readback_gpu(dt);self.feedback.zero_();wp.launch(contact_reaction,self.contacts.soft_contact_max,inputs=[self.contacts.soft_contact_count,self.contacts.soft_contact_shape,self.model.shape_body,self.out_f,self.out_bx,self.state.body_q,self.model.body_com,self.feedback])
  self.current_soft_load.zero_();wp.launch(collect_soft_load,self.contacts.soft_contact_max,inputs=[self.contacts.soft_contact_count,self.contacts.soft_contact_indices,self.contacts.soft_contact_barycentric,self.contacts.soft_contact_shape,self.model.shape_body,self.out_f,self.region_ids,self.hand_body_count,self.current_soft_load]);wp.launch(record_peak,4,inputs=[self.current_soft_load,self.peak_soft_load])
  if not self.indent:
   c=self.rigid_observation;self.rigid.update_contacts(c,self.state);self.current_rigid_load.zero_();wp.launch(collect_rigid_load,c.rigid_contact_max,inputs=[c.rigid_contact_count,c.rigid_contact_shape0,c.rigid_contact_shape1,self.model.shape_body,c.force,self.hand_body_count,self.current_rigid_load]);wp.launch(record_peak,self.hand_body_count,inputs=[self.current_rigid_load,self.peak_rigid_load])
 def readback_gpu(self,dt=.00025):
  c=self.contacts;s=self.state;old=self.next;self.out_reaction.zero_();self.out_f.zero_();self.out_depth.zero_()
  wp.launch(contact_readback,c.soft_contact_max,inputs=[c.soft_contact_count,c.soft_contact_indices,c.soft_contact_barycentric,c.soft_contact_shape,c.soft_contact_body_pos,c.soft_contact_body_vel,c.soft_contact_normal,s.particle_q,self.vbd.particle_q_prev,self.vm.particle_radius,self.vbd.body_particle_contact_penalty_k,self.vbd.body_particle_contact_material_kd,self.vbd.body_particle_contact_material_mu,self.vbd.friction_epsilon,self.vm.shape_body,s.body_q,old.body_q,s.body_qd,self.vm.body_com,self.vm.shape_margin,dt,self.probe,self.out_f,self.out_depth,self.out_normal,self.out_bx,self.out_reaction])
 def read_contacts(self,dt=.00025):
  return self.contacts,int(self.contacts.soft_contact_count.numpy()[0])

 def set_targets(self, targets):
  """Absolute canonical joint positions: radians, or metres for wrist translation."""
  if isinstance(targets,dict):
   values=self.target.numpy()[self.action_indices]*self.signs
   for name,value in targets.items():values[self.action_names.index(name)]=value
  else:values=np.asarray(targets,dtype=float)
  if values.shape!=(len(self.action_names),) or not np.isfinite(values).all():raise ValueError('Expected one finite target per action_names entry')
  if np.any(values<self.action_lower-1e-6) or np.any(values>self.action_upper+1e-6):raise ValueError('Target exceeds joint limits')
  target=self.target.numpy();target[self.action_indices]=values*self.signs;self.target.assign(target)
 def tactile(self, external_only=True):
  """VBD force ON soft tissue, N. No response is fabricated from the display mesh."""
  n=int(self.contacts.soft_contact_count.numpy()[0]);indices=self.contacts.soft_contact_indices.numpy()[:n];bary=self.contacts.soft_contact_barycentric.numpy()[:n]
  forces=self.out_f.numpy()[:n];shapes=self.contacts.soft_contact_shape.numpy()[:n];body=self.model.shape_body.numpy()[shapes]
  keep=(body<0)|(body>=self.hand_body_count) if external_only else np.ones(n,dtype=bool)
  total=np.zeros((4,3));load=np.zeros(4);counts=np.zeros(4,dtype=int)
  for j in range(3):
   valid=keep&(indices[:,j]>=0)&(indices[:,j]<self.real_count)&(bary[:,j]>0)
   ids=np.flatnonzero(valid);regions=self.regions[indices[ids,j]];good=regions>=0;ids=ids[good];regions=regions[good]
   np.add.at(total,regions,forces[ids]*bary[ids,j,None]);np.add.at(load,regions,np.linalg.norm(forces[ids],axis=1)*bary[ids,j]);np.add.at(counts,regions,(np.linalg.norm(forces[ids],axis=1)>1e-9).astype(int))
  return {'regions':self.region_names,'force_on_tissue_N':total,'sum_force_magnitudes_N':load,'active_corner_contributions':counts,'external_only':external_only,'external_window_peak_sum_force_magnitudes_N':self.peak_soft_load.numpy()}
 def observe(self):
  tactile=self.tactile();q=self.state.joint_q.numpy();qd=self.state.joint_qd.numpy()
  return {'joint_names':self.action_names,'joint_position':q[self.action_indices]*self.signs,'joint_velocity':qd[self.action_indices]*self.signs,'body_names':self.body_names_all,'body_pose_xyzw':self.state.body_q.numpy(),'soft_tactile':tactile,'rigid_tactile':self.rigid_tactile(),'wrist_mode':self.wrist,'time_s':self.time}
 def reset(self):
  """Reset this hand/scene instance, including both solvers and collision matching."""
  with wp.ScopedDevice(self.device):
   self.state=self.model.state();self.next=self.model.state()
   if not self.indent:self.rigid.reset(self.state)
   self.vbd.reset(self.state);newton.eval_fk(self.model,self.state.joint_q,self.state.joint_qd,self.state)
   for key,value in vars(self.state).items():
    dest=getattr(self.next,key,None)
    if isinstance(value,wp.array) and isinstance(dest,wp.array):wp.copy(dest,value)
   self.collision.reset_contact_matching();self.feedback.zero_();self.anchor_force.zero_();self.probe_velocity.zero_();self.control.joint_f.zero_()
   self.target.assign(self._initial_q)
   for c in [self.contacts,self.raw_contacts]:c.soft_contact_count.zero_();c.rigid_contact_count.zero_()
   self.out_f.zero_();self.out_depth.zero_();self.out_reaction.zero_();self.out_normal.zero_();self.out_bx.zero_();self.time=0.;self._advance_graph=None;self.current_soft_load.zero_();self.peak_soft_load.zero_();self.rigid_observation.rigid_contact_count.zero_();self.rigid_observation.force.zero_();self.current_rigid_load.zero_();self.peak_rigid_load.zero_()
 def visual_skin(self, **kwargs):
  from .visual import VisualSkin
  return VisualSkin(self.side,self.body_names_all,device=self.device,**kwargs)

 def rigid_tactile(self):
  """Rigid external contact force on each hand body, world N; separate from VBD tissue forces."""
  total=np.zeros((self.hand_body_count,3));load=np.zeros(self.hand_body_count)
  c=self.rigid_observation
  if self.indent or self.time==0:c.rigid_contact_count.zero_()
  n=int(c.rigid_contact_count.numpy()[0])
  if n and c.force is not None:
   sb=self.model.shape_body.numpy();a=sb[c.rigid_contact_shape0.numpy()[:n]];b=sb[c.rigid_contact_shape1.numpy()[:n]];forces=c.force.numpy()[:n,:3]
   for own,other,sign in [(a,b,1.),(b,a,-1.)]:
    keep=(own>=0)&(own<self.hand_body_count)&((other<0)|(other>=self.hand_body_count));np.add.at(total,own[keep],forces[keep]*sign);np.add.at(load,own[keep],np.linalg.norm(forces[keep],axis=1))
  return {'body_names':self.body_names,'force_on_body_N':total,'sum_force_magnitudes_N':load,'external_window_peak_sum_force_magnitudes_N':self.peak_rigid_load.numpy()}
 def advance(self, duration=.01, dt=.00025):
  """Advance live physics with a cached two-substep CUDA graph. Reset invalidates the graph."""
  count=round(duration/dt)
  if count<1 or abs(count*dt-duration)>1e-9:raise ValueError('duration must be a positive integer multiple of dt')
  self.peak_soft_load.zero_();self.peak_rigid_load.zero_()
  start=self.time;remaining=count
  with wp.ScopedDevice(self.device):
   if getattr(self,'_advance_graph',None) is None or getattr(self,'_advance_dt',None)!=dt:
    if remaining<2:
     self.step(dt);return
    self.step(dt);self.step(dt);remaining-=2
    with wp.ScopedCapture(device=self.device) as cap:self.step(dt);self.step(dt)
    self._advance_graph=cap.graph;self._advance_dt=dt
   for _ in range(remaining//2):wp.capture_launch(self._advance_graph)
   if remaining%2:
    self.step(dt);self._advance_graph=None
  self.time=start+duration
